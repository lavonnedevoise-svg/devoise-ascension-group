import Link from "next/link";

export function Button({ href, children, variant = "primary", className = "", ...props }) {
  const base = "inline-flex items-center justify-center rounded-full px-5 py-2.5 text-sm font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-500/60";
  const styles = {
    primary: "bg-gold-500 text-black hover:bg-gold-600",
    ghost: "bg-white/10 text-white hover:bg-white/15",
    outline: "border border-white/20 bg-transparent hover:bg-white/10"
  };

  if (href) {
    const isExternal = /^https?:\/\//.test(href);
    return (
      <Link
        href={href}
        className={`${base} ${styles[variant]} ${className}`}
        target={isExternal ? "_blank" : undefined}
        rel={isExternal ? "noopener noreferrer" : undefined}
      >
        {children}
      </Link>
    );
  }

  return (
    <button className={`${base} ${styles[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
}
