export default function SectionHeading({ eyebrow, title, subtitle }) {
  return (
    <div className="max-w-3xl">
      {eyebrow ? (
        <div className="mb-2 text-xs font-bold uppercase tracking-[0.25em] text-gold-500/90">{eyebrow}</div>
      ) : null}
      <h1 className="text-3xl font-black tracking-tight sm:text-4xl">{title}</h1>
      {subtitle ? <p className="mt-3 text-white/70">{subtitle}</p> : null}
    </div>
  );
}
