export default function TestimonialsGrid({ testimonials }) {
  return (
    <div className="grid gap-6 md:grid-cols-3">
      {testimonials.map((t, idx) => (
        <div key={idx} className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <div className="text-sm text-white/60">{t.service}</div>
          <div className="mt-2 text-lg font-semibold">{t.result}</div>
          <p className="mt-3 text-white/70">“{t.quote}”</p>
          <div className="mt-4 text-sm font-semibold">— {t.name}</div>
        </div>
      ))}
    </div>
  );
}
