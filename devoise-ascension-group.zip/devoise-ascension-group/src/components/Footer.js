import Container from "./Container";
import Link from "next/link";

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-white/10">
      <Container className="py-10">
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="font-semibold">DeVoise Ascension Group</div>
            <div className="text-sm text-white/60">Alignment • Strategy • Execution</div>
          </div>
          <div className="flex flex-wrap gap-4 text-sm text-white/70">
            <Link href="/library">Library</Link>
            <Link href="/services">Services</Link>
            <Link href="/events">Masterclasses</Link>
            <Link href="/about">About</Link>
            <Link href="/contact">Contact</Link>
          </div>
        </div>
        <div className="mt-8 text-xs text-white/50">© {new Date().getFullYear()} DeVoise Ascension Group. All rights reserved.</div>
      </Container>
    </footer>
  );
}
