import { formatMoney } from "../lib/format";
import { Button } from "./Button";

export default function ServiceCard({ service }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-lg font-bold">{service.name}</div>
          <div className="mt-1 text-sm text-white/60">{service.duration}</div>
        </div>
        <div className="rounded-xl bg-gold-500/15 px-3 py-2 text-sm font-bold text-gold-500">{formatMoney(service.price)}</div>
      </div>

      <p className="mt-4 text-white/70">{service.description}</p>

      <ul className="mt-4 space-y-2 text-sm text-white/75">
        {service.includes.map((item) => (
          <li key={item} className="flex gap-2">
            <span className="mt-0.5 text-gold-500">•</span>
            <span>{item}</span>
          </li>
        ))}
      </ul>

      <div className="mt-6">
        <Button href={service.cta?.href || "/contact"}>{service.cta?.label || "Get Started"}</Button>
      </div>

      <div className="mt-4 text-xs text-white/50">
        Note: Payments are non-refundable. No income or outcome guarantees. Implementation remains the client’s responsibility.
      </div>
    </div>
  );
}
