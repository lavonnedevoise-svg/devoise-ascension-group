export function Badge({ children, tone = "neutral" }) {
  const tones = {
    neutral: "bg-white/10 text-white/85",
    gold: "bg-gold-500/20 text-gold-500",
    success: "bg-emerald-500/15 text-emerald-300",
    warning: "bg-amber-500/15 text-amber-300"
  };

  return (
    <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${tones[tone]}`}>
      {children}
    </span>
  );
}
