import Image from "next/image";
import Link from "next/link";
import { Badge } from "./Badge";

export default function BookCard({ book }) {
  const statusTone = book.status === "available" ? "success" : "warning";
  const statusLabel = book.status === "available" ? "Available Now" : "Coming Soon";

  return (
    <div className="group rounded-2xl border border-white/10 bg-white/5 p-4 transition hover:bg-white/7">
      <div className="relative aspect-[2/3] overflow-hidden rounded-xl bg-black/40 shadow-glow">
        <Image
          src={book.cover}
          alt={`${book.title} cover`}
          fill
          sizes="(max-width: 768px) 100vw, 33vw"
          className="object-cover transition duration-300 group-hover:scale-[1.02]"
        />
      </div>

      <div className="mt-4 flex items-center justify-between gap-3">
        <Badge tone={statusTone}>{statusLabel}</Badge>
        <span className="text-xs text-white/50">{book.category}</span>
      </div>

      <div className="mt-3">
        <Link href={`/library/${book.slug}`} className="font-semibold hover:underline">
          {book.title}
        </Link>
        <div className="mt-1 text-sm text-white/60">{book.author}</div>
        <p className="mt-2 text-sm text-white/70 line-clamp-3">{book.tagline}</p>
      </div>

      <div className="mt-4 flex gap-2">
        <Link
          href={`/library/${book.slug}`}
          className="inline-flex flex-1 items-center justify-center rounded-full bg-white/10 px-4 py-2 text-sm font-semibold hover:bg-white/15"
        >
          Details
        </Link>
        {book.status === "available" && book.buyUrl ? (
          <Link
            href={book.buyUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex flex-1 items-center justify-center rounded-full bg-gold-500 px-4 py-2 text-sm font-semibold text-black hover:bg-gold-600"
          >
            Buy
          </Link>
        ) : (
          <Link
            href="/contact"
            className="inline-flex flex-1 items-center justify-center rounded-full border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10"
          >
            Notify Me
          </Link>
        )}
      </div>
    </div>
  );
}
