"use client";

import { useMemo, useState } from "react";

export default function ContactForm() {
  const [status, setStatus] = useState(null);

  const defaultEmail = useMemo(() => {
    // Change this if you prefer a different inbox
    return "lavonnedevoise@gmail.com";
  }, []);

  function onSubmit(e) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const name = form.get("name");
    const email = form.get("email");
    const interest = form.get("interest");
    const message = form.get("message");

    const subject = encodeURIComponent(`[DeVoise Ascension Group] ${interest}`);
    const body = encodeURIComponent(
      `Name: ${name}\nEmail: ${email}\nInterest: ${interest}\n\nMessage:\n${message}\n\n— Sent from DeVoiseAscensionGroup.com`
    );

    window.location.href = `mailto:${defaultEmail}?subject=${subject}&body=${body}`;
    setStatus("Opened your email app — send it and you’re locked in.");
  }

  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
      <form onSubmit={onSubmit} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="text-sm text-white/70">Name</label>
            <input name="name" required className="mt-2 w-full rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-sm outline-none focus:border-gold-500/60" />
          </div>
          <div>
            <label className="text-sm text-white/70">Email</label>
            <input type="email" name="email" required className="mt-2 w-full rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-sm outline-none focus:border-gold-500/60" />
          </div>
        </div>

        <div>
          <label className="text-sm text-white/70">I’m interested in</label>
          <select name="interest" className="mt-2 w-full rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-sm outline-none focus:border-gold-500/60">
            <option>Strategy Session ($47)</option>
            <option>Done-For-You E-Book Creation ($397)</option>
            <option>E-Book Masterclass & Coaching ($2,500)</option>
            <option>Ascension 14 Coaching</option>
            <option>Masterclass / Zoom Intensive</option>
            <option>Books / Partnerships</option>
            <option>Other</option>
          </select>
        </div>

        <div>
          <label className="text-sm text-white/70">Message</label>
          <textarea name="message" rows={5} required className="mt-2 w-full rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-sm outline-none focus:border-gold-500/60" />
        </div>

        <button className="w-full rounded-full bg-gold-500 px-5 py-3 text-sm font-semibold text-black hover:bg-gold-600">
          Send Inquiry
        </button>

        {status ? <div className="text-xs text-emerald-300">{status}</div> : null}
      </form>

      <div className="mt-5 text-xs text-white/50">
        Want a true form submission (no email app)? Swap this to Formspree, ConvertKit, or a custom API route — the site is structured for it.
      </div>
    </div>
  );
}
