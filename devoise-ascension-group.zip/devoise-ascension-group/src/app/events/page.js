import Container from "../../components/Container";
import SectionHeading from "../../components/SectionHeading";
import { Button } from "../../components/Button";
import events from "../../data/events.json";

export const metadata = {
  title: "Masterclasses | DeVoise Ascension Group",
  description: "Masterclasses and Zoom intensives for identity, alignment, and execution."
};

export default function EventsPage() {
  return (
    <div className="py-12">
      <Container>
        <SectionHeading
          eyebrow="Masterclasses"
          title="Trainings that move you forward"
          subtitle="Use this page to host upcoming masterclasses, Zoom intensives, and live containers."
        />

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {events.map((e) => (
            <div key={e.title} className="rounded-2xl border border-white/10 bg-white/5 p-6">
              <div className="text-xl font-bold">{e.title}</div>
              <p className="mt-2 text-white/70">{e.description}</p>
              <div className="mt-6">
                <Button href={e.cta?.href || "/contact"}>{e.cta?.label || "Get Notified"}</Button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 rounded-3xl border border-white/10 bg-gradient-to-r from-white/5 to-gold-500/10 p-8">
          <div className="text-lg font-bold">Want this to be automated?</div>
          <p className="mt-2 text-white/70">
            We can plug this into a simple registration system (ConvertKit, Stripe payment links, Calendly, etc.) so people can sign up and
            you can follow up automatically.
          </p>
          <div className="mt-6">
            <Button href="/contact">Ask about setup</Button>
          </div>
        </div>
      </Container>
    </div>
  );
}
