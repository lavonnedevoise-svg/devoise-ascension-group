import Container from "../../components/Container";
import SectionHeading from "../../components/SectionHeading";
import ContactForm from "../../components/ContactForm";

export const metadata = {
  title: "Contact | DeVoise Ascension Group",
  description: "Book a session or inquire about services."
};

export default function ContactPage() {
  return (
    <div className="py-12">
      <Container>
        <SectionHeading
          eyebrow="Contact"
          title="Book or inquire"
          subtitle="Send one message — we’ll route you to the right next step (session, done-for-you, coaching, masterclass)."
        />

        <div className="mt-10 grid gap-6 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <ContactForm />
          </div>
          <div className="lg:col-span-5">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
              <div className="text-lg font-bold">Fast answers</div>
              <div className="mt-4 space-y-4 text-sm text-white/70">
                <div>
                  <div className="font-semibold text-white">What should I pick?</div>
                  <div className="mt-1">If you need clarity: Strategy Session. If you need delivery: Done-For-You. If you need accountability: Coaching.</div>
                </div>
                <div>
                  <div className="font-semibold text-white">Do you guarantee income?</div>
                  <div className="mt-1">No. We deliver clarity + assets; your results depend on implementation and marketing.</div>
                </div>
                <div>
                  <div className="font-semibold text-white">Can you add payments + registrations?</div>
                  <div className="mt-1">Yes — Stripe, Calendly, ConvertKit, and more can plug in cleanly.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}
