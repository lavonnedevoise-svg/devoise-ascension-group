import Container from "../components/Container";
import SectionHeading from "../components/SectionHeading";
import { Button } from "../components/Button";
import { Badge } from "../components/Badge";
import books from "../data/books.json";
import testimonials from "../data/testimonials.json";
import BookCard from "../components/BookCard";
import TestimonialsGrid from "../components/TestimonialsGrid";
import { slugify } from "../lib/slug";

function withSlugs(items) {
  return items.map((b) => ({ ...b, slug: slugify(b.title) }));
}

export default function Home() {
  const featured = withSlugs(books).slice(0, 6);

  return (
    <div>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-[0.35]" />
        <div className="absolute -top-40 left-1/2 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-gold-500/10 blur-3xl" />

        <Container className="relative py-16 sm:py-20">
          <div className="grid gap-10 lg:grid-cols-12 lg:items-center">
            <div className="lg:col-span-7">
              <div className="flex flex-wrap items-center gap-2">
                <Badge tone="gold">WE TAKE YOU HIGHER</Badge>
                <span className="text-sm text-white/60">Alignment • Strategy • Execution</span>
              </div>

              <h1 className="mt-5 text-4xl font-black tracking-tight sm:text-5xl">
                Ascend your mindset. <span className="text-gold-500">Build your message.</span> Execute your next level.
              </h1>
              <p className="mt-5 max-w-2xl text-white/70">
                DeVoise Ascension Group is a personal development and publishing ecosystem — books, coaching, masterclasses, and done-for-you
                e-book creation designed to help you elevate and monetize your voice.
              </p>

              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Button href="/services">Explore Services</Button>
                <Button href="/library" variant="ghost">Browse the Library</Button>
              </div>

              <div className="mt-8 grid gap-4 sm:grid-cols-3">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <div className="text-sm font-semibold">E-Book Services</div>
                  <div className="mt-1 text-sm text-white/60">Strategy, done-for-you writing, coaching.</div>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <div className="text-sm font-semibold">Ascension 14</div>
                  <div className="mt-1 text-sm text-white/60">A rhythm for discipline, identity, results.</div>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <div className="text-sm font-semibold">Masterclasses</div>
                  <div className="mt-1 text-sm text-white/60">Short intensives + trainings.</div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-glow">
                <div className="text-xs font-bold uppercase tracking-[0.25em] text-white/50">Start here</div>
                <div className="mt-2 text-xl font-bold">Build your first (or next) authority asset.</div>
                <p className="mt-3 text-white/70">
                  If you have a message, we’ll turn it into a clean, professional e-book — and help you package it into a masterclass, coaching
                  offer, or brand.
                </p>
                <div className="mt-6 flex flex-col gap-3">
                  <Button href="/contact">Inquire / Book</Button>
                  <Button href="/events" variant="outline">See Masterclasses</Button>
                </div>
                <div className="mt-5 text-xs text-white/50">No fluff. No confusion. Just clarity + execution.</div>
              </div>
            </div>
          </div>
        </Container>
      </section>

      <section className="py-14">
        <Container>
          <SectionHeading
            eyebrow="Library"
            title="Books, protocols, and frameworks"
            subtitle="Browse what’s available now, and join the waitlist for what’s coming soon."
          />
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((b) => (
              <BookCard key={b.slug} book={b} />
            ))}
          </div>
          <div className="mt-8">
            <Button href="/library" variant="ghost">View Full Library</Button>
          </div>
        </Container>
      </section>

      <section className="py-14">
        <Container>
          <SectionHeading
            eyebrow="Proof"
            title="Results people actually feel"
            subtitle="Testimonials for e-book delivery, coaching, and Ascension 14. Replace these with your real screenshots anytime."
          />
          <div className="mt-10">
            <TestimonialsGrid testimonials={testimonials} />
          </div>
        </Container>
      </section>

      <section className="py-14">
        <Container>
          <div className="rounded-3xl border border-white/10 bg-gradient-to-r from-white/5 to-gold-500/10 p-8 md:p-10">
            <div className="grid gap-6 md:grid-cols-12 md:items-center">
              <div className="md:col-span-8">
                <div className="text-xs font-bold uppercase tracking-[0.25em] text-white/60">Next step</div>
                <div className="mt-2 text-2xl font-black">Want the fastest path to clarity?</div>
                <p className="mt-2 text-white/70">
                  Book the $47 Strategy Session — leave with a clean angle, an outline, and your next moves.
                </p>
              </div>
              <div className="md:col-span-4 md:text-right">
                <Button href="/contact">Book the $47 Session</Button>
              </div>
            </div>
          </div>
        </Container>
      </section>
    </div>
  );
}
