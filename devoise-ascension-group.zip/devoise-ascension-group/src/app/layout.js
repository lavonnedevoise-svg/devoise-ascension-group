import "./globals.css";
import Header from "../components/Header";
import Footer from "../components/Footer";

export const metadata = {
  title: "DeVoise Ascension Group | We Take You Higher",
  description: "Books, masterclasses, and done-for-you e-book services to elevate your mindset, spirituality, and execution.",
  icons: {
    icon: "/favicon.svg"
  },
  openGraph: {
    title: "DeVoise Ascension Group",
    description: "Alignment • Strategy • Execution",
    type: "website"
  }
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
