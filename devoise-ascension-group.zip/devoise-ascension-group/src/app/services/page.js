import Container from "../../components/Container";
import SectionHeading from "../../components/SectionHeading";
import ServiceCard from "../../components/ServiceCard";
import services from "../../data/services.json";

export const metadata = {
  title: "Services | DeVoise Ascension Group",
  description: "E-book strategy, done-for-you creation, and coaching programs."
};

export default function ServicesPage() {
  return (
    <div className="py-12">
      <Container>
        <SectionHeading
          eyebrow="Services"
          title="We turn your message into an authority asset"
          subtitle="Choose your lane: clarity, done-for-you execution, or a coaching container that keeps you consistent."
        />

        <div className="mt-10 grid gap-6 lg:grid-cols-3">
          {services.map((s) => (
            <ServiceCard key={s.name} service={s} />
          ))}
        </div>

        <div className="mt-10 rounded-3xl border border-white/10 bg-white/5 p-8">
          <div className="text-lg font-bold">What you get (the DeVoise standard)</div>
          <div className="mt-3 grid gap-4 md:grid-cols-3">
            <div>
              <div className="font-semibold">Clarity</div>
              <p className="mt-1 text-sm text-white/70">We make the message clean, specific, and positioned for buyers.</p>
            </div>
            <div>
              <div className="font-semibold">Structure</div>
              <p className="mt-1 text-sm text-white/70">Outlines, sections, flow — professional formatting and readability.</p>
            </div>
            <div>
              <div className="font-semibold">Execution</div>
              <p className="mt-1 text-sm text-white/70">You leave with deliverables, next steps, and momentum.</p>
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}
