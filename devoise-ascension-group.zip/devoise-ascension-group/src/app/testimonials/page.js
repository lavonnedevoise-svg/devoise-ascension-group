import Container from "../../components/Container";
import SectionHeading from "../../components/SectionHeading";
import testimonials from "../../data/testimonials.json";
import TestimonialsGrid from "../../components/TestimonialsGrid";
import { Button } from "../../components/Button";

export const metadata = {
  title: "Testimonials | DeVoise Ascension Group",
  description: "Testimonials for e-book delivery, coaching, and Ascension 14."
};

export default function TestimonialsPage() {
  return (
    <div className="py-12">
      <Container>
        <SectionHeading
          eyebrow="Testimonials"
          title="Receipts, not hype"
          subtitle="Swap these placeholders with real screenshots anytime. A clean testimonial wall boosts conversions immediately."
        />

        <div className="mt-10">
          <TestimonialsGrid testimonials={testimonials} />
        </div>

        <div className="mt-10 rounded-3xl border border-white/10 bg-white/5 p-8">
          <div className="text-lg font-bold">Tip</div>
          <p className="mt-2 text-white/70">
            Best proof is simple: a screenshot, the result, and the service used. Keep it clean and consistent.
          </p>
          <div className="mt-6">
            <Button href="/contact" variant="ghost">Send me your screenshots</Button>
          </div>
        </div>
      </Container>
    </div>
  );
}
