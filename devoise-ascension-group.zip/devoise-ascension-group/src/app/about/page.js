import Container from "../../components/Container";
import SectionHeading from "../../components/SectionHeading";
import { Button } from "../../components/Button";

export const metadata = {
  title: "About | DeVoise Ascension Group",
  description: "About DeVoise Ascension Group."
};

export default function AboutPage() {
  return (
    <div className="py-12">
      <Container>
        <SectionHeading
          eyebrow="About"
          title="Built for people with a message"
          subtitle="DeVoise Ascension Group helps creators and leaders turn ideas into assets — books, frameworks, programs, and execution systems."
        />

        <div className="mt-10 grid gap-6 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
              <div className="text-lg font-bold">What we stand on</div>
              <ul className="mt-4 space-y-3 text-white/70">
                <li><span className="text-gold-500">•</span> Alignment first — you don’t build strong results on weak identity.</li>
                <li><span className="text-gold-500">•</span> Clarity over complexity — simple, clean frameworks win.</li>
                <li><span className="text-gold-500">•</span> Execution matters — we turn ideas into deliverables.</li>
              </ul>
              <div className="mt-6 text-sm text-white/60">
                Signature line: <span className="text-white">WE TAKE YOU HIGHER</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-white/5 to-gold-500/10 p-8">
              <div className="text-xs font-bold uppercase tracking-[0.25em] text-white/60">Start now</div>
              <div className="mt-2 text-2xl font-black">Your next asset is one decision away.</div>
              <p className="mt-3 text-white/70">Book a strategy call or inquire about done-for-you delivery.</p>
              <div className="mt-6 flex flex-col gap-3">
                <Button href="/contact">Inquire</Button>
                <Button href="/services" variant="ghost">See Services</Button>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}
