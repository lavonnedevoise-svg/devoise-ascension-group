import Container from "../../components/Container";
import SectionHeading from "../../components/SectionHeading";
import BookCard from "../../components/BookCard";
import books from "../../data/books.json";
import { slugify } from "../../lib/slug";

export const metadata = {
  title: "Library | DeVoise Ascension Group",
  description: "Browse the DeVoise Ascension Group library of books, protocols, and frameworks."
};

export default function LibraryPage() {
  const list = books.map((b) => ({ ...b, slug: slugify(b.title) }));

  return (
    <div className="py-12">
      <Container>
        <SectionHeading
          eyebrow="Library"
          title="The DeVoise Library"
          subtitle="Available books link out to Amazon. Coming-soon titles can be waitlisted so you never miss a launch."
        />

        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((b) => (
            <BookCard key={b.slug} book={b} />
          ))}
        </div>
      </Container>
    </div>
  );
}
