import Container from "../../../components/Container";
import { Button } from "../../../components/Button";
import { Badge } from "../../../components/Badge";
import books from "../../../data/books.json";
import Image from "next/image";
import { slugify } from "../../../lib/slug";
import Link from "next/link";

export function generateStaticParams() {
  return books.map((b) => ({ slug: slugify(b.title) }));
}

export default function BookDetail({ params }) {
  const list = books.map((b) => ({ ...b, slug: slugify(b.title) }));
  const book = list.find((b) => b.slug === params.slug);

  if (!book) {
    return (
      <div className="py-12">
        <Container>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-8">
            <div className="text-xl font-bold">Book not found</div>
            <p className="mt-2 text-white/70">Try the library page.</p>
            <div className="mt-6"><Button href="/library">Back to Library</Button></div>
          </div>
        </Container>
      </div>
    );
  }

  const statusTone = book.status === "available" ? "success" : "warning";
  const statusLabel = book.status === "available" ? "Available Now" : "Coming Soon";

  return (
    <div className="py-12">
      <Container>
        <div className="mb-6 text-sm text-white/60">
          <Link href="/library" className="hover:underline">Library</Link> <span className="text-white/40">/</span> {book.title}
        </div>

        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <div className="relative aspect-[2/3] overflow-hidden rounded-2xl border border-white/10 bg-black/40 shadow-glow">
              <Image src={book.cover} alt={`${book.title} cover`} fill className="object-cover" sizes="(max-width: 1024px) 100vw, 33vw" />
            </div>
          </div>

          <div className="lg:col-span-8">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone={statusTone}>{statusLabel}</Badge>
              <span className="text-sm text-white/60">{book.category}</span>
            </div>

            <h1 className="mt-4 text-3xl font-black tracking-tight sm:text-4xl">{book.title}</h1>
            <div className="mt-2 text-white/60">{book.author}</div>

            <p className="mt-5 max-w-2xl text-white/70">{book.tagline}</p>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                <div className="text-sm font-semibold">Highlights</div>
                <ul className="mt-3 space-y-2 text-sm text-white/75">
                  {book.highlights.map((h) => (
                    <li key={h} className="flex gap-2"><span className="text-gold-500">•</span><span>{h}</span></li>
                  ))}
                </ul>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                <div className="text-sm font-semibold">Formats</div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {book.format.map((f) => (
                    <span key={f} className="rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-white/80">{f}</span>
                  ))}
                </div>
                <div className="mt-6 text-xs text-white/50">Need help packaging your message into a book + offer? That’s what we do.</div>
              </div>
            </div>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              {book.status === "available" && book.buyUrl ? (
                <Button href={book.buyUrl}>Buy on Amazon</Button>
              ) : (
                <Button href="/contact">Join the Waitlist</Button>
              )}
              <Button href="/services" variant="ghost">See Services</Button>
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}
